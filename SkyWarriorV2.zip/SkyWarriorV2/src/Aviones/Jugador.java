package Aviones;

public class Jugador extends Aviones {


	public Jugador(int vida, int fuerza, int defensa) {
		super(vida,fuerza,defensa);
	}

	
}

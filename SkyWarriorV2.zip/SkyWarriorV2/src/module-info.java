/**
 * 
 */
/**
 * @author alvar
 *
 */
module SkyWarriors {
}
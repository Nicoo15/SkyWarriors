package Aviones;

public class F18 extends Jugador {

	public F18(int vida, int fuerza, int defensa) {
		super(vida, fuerza, defensa);
		// TODO Auto-generated constructor stub
	}

}

package Aviones;

public class Tu2 extends Enemigo {

	public Tu2(int vida, int fuerza, int defensa) {
		super(vida, fuerza, defensa);
		// TODO Auto-generated constructor stub
	}

}

package Aviones;

public interface FabricaAviones {
	public Aviones FabricaCaza(int n);

}

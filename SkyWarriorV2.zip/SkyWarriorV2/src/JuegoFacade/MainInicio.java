package JuegoFacade;

public class MainInicio {
	public static void main(String[] args) {
		DesarrolloJuego c = new DesarrolloJuego();
		c.todo();
	}
}
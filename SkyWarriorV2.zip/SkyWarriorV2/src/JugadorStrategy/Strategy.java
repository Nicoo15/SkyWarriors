package JugadorStrategy;

import Aviones.*;

public interface Strategy {

	void eleccionInicial(Aviones j);
}

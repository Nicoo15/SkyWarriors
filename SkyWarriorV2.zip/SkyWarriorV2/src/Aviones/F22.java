package Aviones;

public class F22 extends Jugador{

	public F22(int vida, int fuerza, int defensa) {
		super(vida, fuerza, defensa);
		// TODO Auto-generated constructor stub
	}


}

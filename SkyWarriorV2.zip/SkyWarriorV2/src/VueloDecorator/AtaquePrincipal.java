package VueloDecorator;

public class AtaquePrincipal implements Ataque {

	public String infoAtaque() {
		return "";
	}
}

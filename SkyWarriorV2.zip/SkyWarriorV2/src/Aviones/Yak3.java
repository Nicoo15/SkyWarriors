package Aviones;

public class Yak3 extends Enemigo{

	public Yak3(int vida, int fuerza, int defensa) {
		super(vida, fuerza, defensa);
		// TODO Auto-generated constructor stub
	}

}

package Aviones;

public class Enemigo extends Aviones {
	

	public Enemigo(int vida, int fuerza, int defensa) {
		super(vida,fuerza,defensa);
		
	}

	
}

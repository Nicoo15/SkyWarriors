package VueloDecorator;

public interface Ataque {
	String infoAtaque();
}
